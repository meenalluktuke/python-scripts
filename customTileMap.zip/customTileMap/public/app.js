define(function (require) {
  const visTypes = require('plugins/customTileMap/ui/registry/vis_types');
  visTypes.register(require('plugins/customTileMap/customTileMap'));
});
