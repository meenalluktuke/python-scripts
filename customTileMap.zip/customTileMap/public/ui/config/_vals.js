define(function (require) {
  return function ConfigValsService() {
    return {};
  };
});
