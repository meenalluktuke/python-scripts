describe('Notifier', function () {

  describe('Message formatters', function () {
    require('./lib/_format_es_msg');
    require('./lib/_format_msg');
  });

});
