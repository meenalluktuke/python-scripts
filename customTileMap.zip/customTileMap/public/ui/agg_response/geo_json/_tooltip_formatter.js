define(function (require) {
  return function TileMapTooltipFormatter($compile, $rootScope, Private) {
    var $ = require('jquery');
    var _ = require('lodash');

    var fieldFormats = Private(require('ui/registry/field_formats'));
    var $tooltipScope = $rootScope.$new();
    var $el = $('<div>').html(require('ui/agg_response/geo_json/_tooltip.html'));
    $compile($el)($tooltipScope);

    return function tooltipFormatter(feature) {
      if (!feature) return '';

      var value = feature.properties.value;
	 
	  var type = feature.properties.typehash;
      var acr = feature.properties.aggConfigResult;
	  
      var vis = acr.aggConfig.vis;
	  let info = feature.properties.info;
      var metricAgg = acr.aggConfig;
	  
      var geoFormat = _.get(vis.aggs, 'byTypeName.geohash_grid[0].format');
      if (!geoFormat) geoFormat = fieldFormats.getDefaultInstance('geo_point');

	  let value1 = feature.properties.value1;
	  
	  if(value1!==undefined)
	  {
		   
		   var acr1 = feature.properties.aggConfigResult1;
		   var metricAgg1 = acr1.aggConfig;
		   
		   //console.log("value1 is not undefined"+value1);
	  }
	  
	  if(value1===undefined||value1===0)
	  {
		  //console.log("value1 is undefined "+value1);
	  if(type!==undefined && info!==undefined)
	  {
		  
		$tooltipScope.details = [
        {
          label: metricAgg.makeLabel(),
          value: metricAgg.fieldFormatter()(value)
        },
		{
			label: "Data Type",
			value: type
		},
		{
			label: "Type of facility",
			value: info
		}
		
      ];  
	  }
	  else if(type!==undefined && info===undefined)
	  {
		$tooltipScope.details = [
        {
          label: metricAgg.makeLabel(),
          value: metricAgg.fieldFormatter()(value)
        },
		{
			label: "Data Type",
			value: type
		}  
		]  
	  }
	  else 
	  {
		  
		
		$tooltipScope.details = [
        {
          label: metricAgg.makeLabel(),
          value: metricAgg.fieldFormatter()(value)
        }	
      ];  
	  
		  
	  }
	  }
	  else if(value1!==undefined||value1>0){
		  //console.log("value1 is not undefined for labels"+value1);
		  
		if(type!==undefined && info!==undefined)
	  {
		  
		$tooltipScope.details = [
        {
          label: metricAgg1.makeLabel(),
          value: metricAgg1.fieldFormatter()(value1)
        },
		{
			label: "Data Type",
			value: type
		},
		{
			label: "Type of facility",
			value: info
		}
		
      ];  
	  }
	  else if(type!==undefined && info===undefined)
	  {
		$tooltipScope.details = [
        {
          label: metricAgg1.makeLabel(),
          value: metricAgg1.fieldFormatter()(value1)
        },
		{
			label: "Data Type",
			value: type
		}  
		]  
	  }
	  else
	  {
  
		$tooltipScope.details = [
        {
          label: metricAgg1.makeLabel(),
          value: metricAgg1.fieldFormatter()(value1)
        }	
      ];  
	  
		  
	  }  
	  }
      

      $tooltipScope.$apply();

      return $el.html();
    };
  };
});
