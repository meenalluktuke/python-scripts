define(function (require) {
  return function TileMapTooltipFormatter($compile, $rootScope, Private) {
    var $ = require('jquery');
    var _ = require('lodash');
    var info=[];
    var fieldFormats = Private(require('ui/registry/field_formats'));
    var $tooltipScope = $rootScope.$new();
    var $el = $('<div>').html(require('ui/agg_response/geo_json/_tooltip.html'));
    $compile($el)($tooltipScope);

    return function tooltipFormatter(feature) {
      if (!feature) return '';

      var value = feature.properties.value;
      var value1 = feature.properties.value1 * 100 + '%';
      var value2 = feature.properties.value2 * 100 + '%';
	    var type = feature.properties.typehash;
      var acr = feature.properties.aggConfigResult;

      var vis = acr.aggConfig.vis;
      var i;

	    info = feature.properties.infoData;
      var metricAgg = acr.aggConfig;
      //console.log("In tooltip formatter");
      //console.log(info);
      var geoFormat = _.get(vis.aggs, 'byTypeName.geohash_grid[0].format');
      if (!geoFormat) geoFormat = fieldFormats.getDefaultInstance('geo_point');

      if(type === "Potential Target")
      {
        $tooltipScope.details = [
        		{
        			label:  type,
        			value: ""
        		},
        		{
              label: info[0].title,
              value: info[0].data
            },
            {
               label: info[1].title,
               value: info[1].data
            },
            {
              label: "Likelihood Score",
              value: value1
            }
            ]
      }
      else if(type === "NBREM Asset")
      {
              $tooltipScope.details = [
              		{
              			label:  type,
              			value: ""
              		},
              		{
                    label: info[0].title,
                    value: info[0].data
                  },
                  {
                     label: info[1].title,
                     value: info[1].data
                  },
                  {
                    label: "NBRE Share %",
                    value: value2
                  }
                  ]
            }
       else if(type === "Historical Data")
       {
                $tooltipScope.details = [
                		{
                			label:  type,
                			value: ""
                		},
                		{
                      label: info[0].title,
                      value: info[0].data
                    },
                    {
                       label: info[1].title,
                       value: info[1].data
                    },
                    {
                      label: "Count",
                      value: value
                    }
                    ]
       }

      $tooltipScope.$apply();

      return $el.html();
    };
  };
});
