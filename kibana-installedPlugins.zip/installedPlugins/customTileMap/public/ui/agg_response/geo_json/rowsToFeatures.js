define(function (require) {
  let decodeGeoHash = require('plugins/customTileMap/ui/utils/decode_geo_hash');
  let AggConfigResult = require('plugins/customTileMap/ui/Vis/AggConfigResult');
  let _ = require('lodash');
  let infoData=[];
  var metricvalus=[];
  var j=0;

  function getAcr(val) {
    return val instanceof AggConfigResult ? val : null;
  }

  function unwrap(val) {
    return getAcr(val) ? val.value : val;
  }

  function convertRowsToFeatures(table, geoI,geoC,info, metric, click_info) {

  //console.log("In rows to Feature");
  //console.log(info);
    return _.transform(table.rows, function (features, row) {
      let geohash = unwrap(row[geoI]);
      if (!geohash) return;

    let typehash="NA";
     if(geoC!= -1)
	    typehash = unwrap(row[geoC]);
	   else
	    typehash = "NA";
	  let click_val="";
    if(click_info != -1)
	    click_val=unwrap(row[click_info]);
	  else
	    click_val="No ID available";

    let i=0;
    j++;
    var title=[], dataval=[];
    //console.log(info.length);
    for(i=0;i<info.length;i++)
    {
          if(info[i].title === null || info[i].title === undefined)
            title[i]="Info"
           else
            title[i]=info[i].title
           dataval[i] = unwrap(row[info[i].data]);
      	   //console.log(infoData[i]);
      	  //console.log(info[i].title);


    }
    infoData[j]=[{title:title[0],data:dataval[0]},{title:title[1],data:dataval[1]}];
    //console.log(infoData[j][0]);

     // console.log("Length of infoData:"+infoData.length);
      // fetch latLn of northwest and southeast corners, and center point
      let location = decodeGeoHash(geohash);




      let centerLatLng = [
        location.latitude[2],
        location.longitude[2]
      ];

      // order is nw, ne, se, sw
      let rectangle = [
        [location.latitude[0], location.longitude[0]],
        [location.latitude[0], location.longitude[1]],
        [location.latitude[1], location.longitude[1]],
        [location.latitude[1], location.longitude[0]],
      ];

      // geoJson coords use LngLat, so we reverse the centerLatLng
      // See here for details: http://geojson.org/geojson-spec.html#positions
      features.push({
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: centerLatLng.slice(0).reverse()
        },
        properties: {
          geohash: geohash,
          value: unwrap(row[metric[0]]),
		      value1: unwrap(row[metric[1]]),
		      value2: unwrap(row[metric[2]]),
		      typehash: typehash,
		      infoData:infoData[j],
		      info:click_val,
          aggConfigResult: getAcr(row[metric[0]]),
		      aggConfigResult1: getAcr(row[metric[1]]),
		      aggConfigResult2: getAcr(row[metric[2]]),
          center: centerLatLng,
          rectangle: rectangle
        }
      });
    }, []);
  }

  return convertRowsToFeatures;
});
