define(function (require) {
  return function TileMapConverterFn(Private, timefilter, $compile, $rootScope) {
    let _ = require('lodash');
    let metric = [];
    let infodata = [];
    let title="";
    let title1="";
    let title2="";
    let rowsToFeatures = require('plugins/customTileMap/ui/agg_response/geo_json/rowsToFeatures');
    let tooltipFormatter = Private(require('plugins/customTileMap/ui/agg_response/geo_json/_tooltip_formatter'));
    let info=[];

    return function (vis, table) {

      //console.log("In geo_json");
      //console.log(table);

      function columnIndexbyId(schema) {
              return _.findIndex(table.columns, function (col) {
                return col.aggConfig.id === schema;
              });
            }
      function columnIndex(schema) {
        return _.findIndex(table.columns, function (col) {
          return col.aggConfig.schema.name === schema;
        });
      }

      let geoI = columnIndex('segment');
      let geoC = columnIndex('segment1');
	    infodata[0] = columnIndex('segment2');
	    infodata[1] = columnIndex('segment22');
      let metricI = columnIndex('metric');
	    let metricII = columnIndex('metric1');
      let metricIII = columnIndex('metric2');

      let click_info = columnIndex('segment3');

      metric = [metricI,metricII,metricIII];


      //console.log(title+"  "+title1);
      info[0]={title:"Target/Type of Facility", data:infodata[0]};
      info[1]={title:"Incident Date", data:infodata[1]};
      //console.log("Array of infoData");
      //console.log(infodata[0]+"  "+infodata[1]);

      let geoAgg = _.get(table.columns, [geoI, 'aggConfig']);
	    let geoCAgg = _.get(table.columns, [geoC, 'aggConfig']);


      let metricAgg = _.get(table.columns, [metricI, 'aggConfig']);
	    let features = rowsToFeatures(table, geoI, geoC,info, metric,click_info);
      let values = features.map(function (feature) {
        return feature.properties.value;
      });

      return {
        title: table.title(),
        valueFormatter: metricAgg && metricAgg.fieldFormatter(),
        tooltipFormatter: tooltipFormatter,
        geohashGridAgg: geoAgg,
        geoJson: {
          type: 'FeatureCollection',
          features: features,
          properties: {
            min: _.min(values),
            max: _.max(values),
            zoom: _.get(geoAgg, 'params.mapZoom'),
            center: _.get(geoAgg, 'params.mapCenter')
          }
        }
      };
    };
  };
});
