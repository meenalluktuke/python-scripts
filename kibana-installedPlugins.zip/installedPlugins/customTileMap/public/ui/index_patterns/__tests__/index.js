describe('Index Patterns', function () {
  require('./_index_pattern');
  require('./_cast_mapping_type');
  require('./_map_field');
  require('./_pattern_to_wildcard');
  require('./_get_computed_fields');
  require('./_FieldFormat');
});
