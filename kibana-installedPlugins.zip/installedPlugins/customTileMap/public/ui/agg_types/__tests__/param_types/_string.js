let _ = require('lodash');
let expect = require('expect.js');
let ngMock = require('ngMock');

module.exports = describe('String', function () {
  let paramName = 'json_test';
  let BaseAggParam;
  let StringAggParam;
  let aggParam;
  let aggConfig;
  let output;

  function initAggParam(config) {
    config = config || {};
    let defaults = {
      name: paramName,
      type: 'string'
    };

    aggParam = new StringAggParam(_.defaults(config, defaults));
  }

  beforeEach(ngMock.module('kibana'));

  // fetch our deps
  beforeEach(ngMock.inject(function (Private) {
    BaseAggParam = Private(require('plugins/customTileMap/ui/agg_types/param_types/base'));
    StringAggParam = Private(require('plugins/customTileMap/ui/agg_types/param_types/string'));

    aggConfig = { params: {} };
    output = { params: {} };
  }));

  describe('constructor', function () {
    it('it is an instance of BaseAggParam', function () {
      initAggParam();
      expect(aggParam).to.be.a(BaseAggParam);
    });
  });

  describe('write', function () {
    it('should append param by name', function () {
      let paramName = 'testing';
      let params = {};
      params[paramName] = 'some input';

      initAggParam({ name: paramName });

      aggConfig.params = params;
      aggParam.write(aggConfig, output);

      expect(output.params).to.eql(params);
    });

    it('should not be in output with empty input', function () {
      let paramName = 'more_testing';
      let params = {};
      params[paramName] = '';

      initAggParam({ name: paramName });

      aggConfig.params = params;
      aggParam.write(aggConfig, output);

      expect(output.params).to.eql({});
    });
  });
});
