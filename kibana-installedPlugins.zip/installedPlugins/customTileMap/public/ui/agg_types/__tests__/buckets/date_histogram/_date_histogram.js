describe('Date Histogram Agg', function () {
  require('./_editor');
  require('./_params');
});
