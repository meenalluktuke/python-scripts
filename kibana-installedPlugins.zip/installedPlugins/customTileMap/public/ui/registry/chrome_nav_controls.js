define(function (require) {
  return require('plugins/customTileMap/ui/registry/_registry')({
    name: 'chromeNavControls',
    order: ['order']
  });
});
