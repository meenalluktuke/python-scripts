define(function (require) {
  function customTileMapVisType(Private, getAppState, courier,config) {
    const VislibVisType = Private(require('plugins/customTileMap/ui/vislib_vis_type/VislibVisType'));
    const Schemas = Private(require('plugins/customTileMap/ui/Vis/Schemas'));
    const geoJsonConverter = Private(require('plugins/customTileMap/ui/agg_response/geo_json/geo_json'));
    const _ = require('lodash');
    const supports = require('plugins/customTileMap/ui/utils/supports');
    const maxbuckets = 2;

    return new VislibVisType({
      name: 'custom_tile_map',
      title: 'Custom Tile map',
      icon: 'fa-map-signs',
      description: 'Your source for custom geographic maps. Requires an elasticsearch geo_point field. String fields can be selected to split by color, add click information and hover details.',
      params: {
        defaults: {
          mapType: 'Scaled Circle Markers',
          isDesaturated: true,
          addTooltip: true,
          heatMaxZoom: 16,
          heatMinOpacity: 0.1,
          heatRadius: 25,
          heatBlur: 15,
          heatNormalizeData: true,
          wms: config.get('visualization:tileMap:WMSdefaults')
        },
        mapTypes: ['Scaled Circle Markers', 'Shaded Circle Markers', 'Shaded Geohash Grid', 'Heatmap'],
        canDesaturate: !!supports.cssFilters,
        editor: require('plugins/customTileMap/editors/custom_tile_map.html')
      },
      listeners: {
        rectangle: function (event) {
          const agg = _.get(event, 'chart.geohashGridAgg');
          if (!agg) return;

          const pushFilter = Private(require('plugins/customTileMap/ui/filter_bar/push_filter'))(getAppState());
          const indexPatternName = agg.vis.indexPattern.id;
          const field = agg.fieldName();
          const filter = {geo_bounding_box: {}};
          filter.geo_bounding_box[field] = event.bounds;

          pushFilter(filter, false, indexPatternName);
        },
        mapClick: function(event){
        const agg = _.get(event, 'chart.geohashGridAgg');
                  if (!agg) return;
        agg.params.mapCenter = [event.center.lat, event.center.lng];
        if (!editableVis) return;

                  const editableAgg = editableVis.aggs.byId[agg.id];
                  if (editableAgg) {
                    editableAgg.params.mapZoom = event.zoom;
                    editableAgg.params.mapCenter = [event.center.lat, event.center.lng];
                  }
         console.log("In mouse click event");

        },
        mapMoveEnd: function (event) {
          const agg = _.get(event, 'chart.geohashGridAgg');
          if (!agg) return;

          agg.params.mapZoom = event.zoom;
          agg.params.mapCenter = [event.center.lat, event.center.lng];

          const editableVis = agg.vis.getEditableVis();
          if (!editableVis) return;

          const editableAgg = editableVis.aggs.byId[agg.id];
          if (editableAgg) {
            editableAgg.params.mapZoom = event.zoom;
            editableAgg.params.mapCenter = [event.center.lat, event.center.lng];
          }
        },
        mapZoomEnd: function (event) {
          const agg = _.get(event, 'chart.geohashGridAgg');
          if (!agg || !agg.params.autoPrecision) return;

          // zoomPrecision maps event.zoom to a geohash precision value
          // event.limit is the configurable max geohash precision
          // default max precision is 7, configurable up to 12
          const zoomPrecision = {
            1: 4,
            2: 4,
            3: 4,
            4: 4,
            5: 5,
            6: 5,
            7: 5,
            8: 6,
            9: 6,
            10: 6,
            11: 6,
            12: 7,
            13: 7,
            14: 8,
            15: 9,
            16: 10,
            17: 11,
            18: 12
          };

          const precision = config.get('visualization:tileMap:maxPrecision');
          agg.params.precision = Math.min(zoomPrecision[event.zoom], precision);

          courier.fetch();
        }
      },
      responseConverter: geoJsonConverter,
      schemas: new Schemas([
        {
          group: 'metrics',
          name: 'metric',
          title: 'Value',
          min: 1,
          max: 1,
          aggFilter: ['count', 'avg', 'sum', 'min', 'max', 'cardinality'],
          defaults: [
            { schema: 'metric', type: 'count' }
          ]
        },
		  {
          group: 'metrics',
          name: 'metric1',
          title: 'Value1',
          min: 0,
          max: 1,
          aggFilter: ['count', 'avg', 'sum', 'min', 'max', 'cardinality']
        },
        {
          group: 'metrics',
          name: 'metric2',
          title: 'Value2',
          min: 0,
          max: 1,
          aggFilter: ['count', 'avg', 'sum', 'min', 'max', 'cardinality']
        },
        {
          group: 'buckets',
          name: 'segment',
          title: 'Geo Coordinates',
          aggFilter: 'geohash_grid',
          min: 1,
          max: 1
        },
        {
        group: 'buckets',
        name: 'segment1',
        title: 'Split for Colors',
        min: 0,
        max: 1,
        aggFilter: ['terms', 'significant_terms']
        },
        {
        group: 'buckets',
        name: 'segment2',
        title: 'Split for Information',
        min: 0,
        max: 1,
        aggFilter: ['terms', 'significant_terms']
        },
        {
                group: 'buckets',
                name: 'segment22',
                title: 'Split for Information 2',
                min: 0,
                max: 1,
                aggFilter: ['terms', 'significant_terms']
                },
        {
                group: 'buckets',
                name: 'segment3',
                title: 'ID for click',
                min: 0,
                max: 1,
                aggFilter: ['terms', 'significant_terms']
        }
      ])
    });
    }
  require('ui/registry/vis_types').register(customTileMapVisType);
  return customTileMapVisType;

});
